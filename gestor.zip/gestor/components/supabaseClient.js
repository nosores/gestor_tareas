import { createClient } from '@supabase/supabase-js';

// Reemplaza estos valores con tus credenciales de Supabase
const SUPABASE_URL = 'https://iojsgedvywhlfvcuktdj.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlvanNnZWR2eXdobGZ2Y3VrdGRqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjk4MjY3ODcsImV4cCI6MjA0NTQwMjc4N30.t06n0-wEYU8j_hCK9E33nF2RvVF_ansO4OeadMEF-Ws';

// Crea un cliente de Supabase
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
