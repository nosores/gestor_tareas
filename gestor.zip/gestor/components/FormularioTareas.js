import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

export default function FormularioTareas({ agregarTarea, tareaActual }) {
  // Estado para controlar el texto ingresado en el formulario
  const [nombre, setNombre] = useState('');

  // Efecto para cargar la tarea actual en el formulario cuando cambia
  useEffect(() => {
    if (tareaActual.id) {
      setNombre(tareaActual.nombre);
    } else {
      setNombre('');
    }
  }, [tareaActual]);

  // Función para manejar el envío del formulario
  const manejarEnvio = () => {
    if (nombre.trim()) {
      agregarTarea({ id: tareaActual.id, nombre });
      setNombre(''); // Limpiar el campo de texto después de enviar
    }
  };

  return (
    <View style={styles.formulario}>
      <TextInput
        style={styles.input}
        placeholder="Escribe una tarea..."
        value={nombre}
        onChangeText={setNombre}
      />
      <Button title={tareaActual.id ? "Guardar cambios" : "Agregar tarea"} onPress={manejarEnvio} color="#0D47A1" />
    </View>
  );
}

const styles = StyleSheet.create({
  formulario: {
    marginBottom: 20,
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#0055aa',
    marginBottom: 10,
    padding: 8,
    fontSize: 16,
  },
});
