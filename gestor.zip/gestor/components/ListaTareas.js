import React from 'react';
import { View, Text, FlatList, Button, StyleSheet } from 'react-native';

export default function ListaTareas({ tareas, onEliminar, onEditar }) {
  return (
    <FlatList
      data={tareas}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <View style={styles.tarea}>
          <Text style={styles.nombre}>{item.nombre}</Text>
          <View style={styles.botones}>
            <Button title="Editar" onPress={() => onEditar(item)} />
            <Button title="Eliminar" color="red" onPress={() => onEliminar(item.id)} />
          </View>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  tarea: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    marginVertical: 5,
    backgroundColor: '#f3f3f3',
    borderRadius: 5,
  },
  nombre: {
    fontSize: 16,
    flex: 1,
  },
  botones: {
    flexDirection: 'row',
    gap: 10,
  },
});
