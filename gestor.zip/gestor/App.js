import React, { useState } from 'react';
import { supabase } from './components/supabaseClient';
import { View, Text, StyleSheet, FlatList , Image} from 'react-native';
import ListaTareas from './components/ListaTareas';
import FormularioTareas from './components/FormularioTareas';

export default function App() {
  // Estado para almacenar todas las tareas
  const [tareas, setTareas] = useState([]);
  // Estado para almacenar la tarea actual en edicion
  const [tareaActual, setTareaActual] = useState({ id: null, nombre: '' });

  // Funcion para agregar o actualizar una tarea
  const agregarTarea = (tarea) => {
    if (tarea.id) {
      // Editar tarea existente
      setTareas(tareas.map(t => (t.id === tarea.id ? tarea : t)));
    } else {
      // Agregar nueva tarea
      setTareas([...tareas, { ...tarea, id: Date.now().toString() }]);
    }
    setTareaActual({ id: null, nombre: '' }); // Limpiar el formulario despues de agregar/editar
  };

  // Funcion para eliminar una tarea
  const eliminarTarea = (id) => {
    setTareas(tareas.filter(t => t.id !== id));
  };

  // Funcion para cargar una tarea en el formulario para editar
  const editarTarea = (tarea) => {
    setTareaActual(tarea);
  };


  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gestor de Tareas</Text>
       <Image source={require('./assets/isftlogo.jpg')} style={styles.logo} />
      <FormularioTareas agregarTarea={agregarTarea} tareaActual={tareaActual} />
      {tareas.length > 0 ? (
        <ListaTareas tareas={tareas} onEliminar={eliminarTarea} onEditar={editarTarea} />
      ) : (
        <Text style={styles.noTareas}>No hay tareas pendientes.</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
    
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  noTareas: {
    textAlign: 'center',
    fontSize: 16,
    color: '#888',
  },
  logo: {
  width: 60,
  height: 60,
  alignSelf: 'center',
  marginBottom: 20,
  alignContent: 'justify',
},

});
